# Anti Suicide
### Anti-Suicide relocation

Simple addon to avoid suicide relocation. Everytime someone revives it will store the location they spawned.
If they suicide, it will use that location, if it was not suicide, it will create a new revive location and store it.


## Available Permissions
Permission | Action
------- | -------
anti-suicide.imune			| group is not affected by anti-suicide rules (admin have this by default)


## Other Options
Option | Action
------- | -------
Enabled							| Enables and disables the addon
ResetSuicideCountAfterKick		| Resets the player suicide count after the player is kicked
MaxSuicidesBeforeKick			| Maximum number of suicides before player is kicked
 